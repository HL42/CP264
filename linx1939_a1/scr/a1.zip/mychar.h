/**
 * -------------------------------------
 * @file  mychar.h
 * file description
 * -------------------------------------
 * @author HunterLin, 169061939, linx1939@mylaurier
 *
 * @version 2025-01-15
 *
 * -------------------------------------
 */
#ifndef MYCHAR_H_
#define MYCHAR_H_

/**
 *  add your comment
 */
int mytype(char c);

/**
 *  add your comment
 */
char case_flip(char c);

/**
 *  add your comment
 */
int digit_to_int(char c);


#endif /* MYCHAR_H_ */
